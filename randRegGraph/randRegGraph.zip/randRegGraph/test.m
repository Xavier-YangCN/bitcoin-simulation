fprintf('-------- test createRandRegGraph() ------------\n');

n = 1000;
d = 10;

G = createRandRegGraph(n, d);

fprintf('-------- end ------------\n');